# Brainstorming Session

## Date
`{{date}}`

### Idea 1

#### Prompt
```
{{prompt1}}
```

#### Response
```
{{response1}}
```

### Idea 2

#### Prompt
```
{{prompt2}}
```

#### Response
```
{{response2}}
```

### Refined Ideas
- **Idea 1**: {{refined_idea1}}
- **Idea 2**: {{refined_idea2}}

### Action Items
- [ ] {{action_item1}}
- [ ] {{action_item2}}
