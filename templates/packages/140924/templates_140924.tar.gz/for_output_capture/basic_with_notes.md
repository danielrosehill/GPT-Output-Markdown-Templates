# GPT Output

## Date
`{{date}}`

## Prompt
```
{{prompt}}
```

## Response
```
{{response}}
```

## Notes
- {{note1}}
- {{note2}}
